﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace Sample.helper
{
    public static class PagingHelpers
    {
        public static MvcHtmlString PageLinks(this HtmlHelper html, PagingInfo pagingInfo,string url, Func<int, string> pageUrl)
        {
            StringBuilder result = new StringBuilder();
            TagBuilder ulTag = new TagBuilder("ul");
            ulTag.AddCssClass("pagination");
            TagBuilder anchor = new TagBuilder("a");
            TagBuilder litag = new TagBuilder("li");

            #region set first page
            litag.AddCssClass("page-item");
            anchor.AddCssClass("page-link");
            if (pagingInfo.CurrentPage == 1)
            {
                litag.AddCssClass("disabled");
                anchor.MergeAttribute("href", "javascript:void(0);");
            }
            else
            {
                anchor.MergeAttribute("href", url);
            }
            anchor.InnerHtml = "First".ToString();
            litag.InnerHtml = anchor.ToString();
            result.Append(litag.ToString());
            #endregion

            #region set Previous page

            anchor = new TagBuilder("a");
            litag = new TagBuilder("li");
            litag.AddCssClass("page-item");
            anchor.AddCssClass("page-link");
            if (pagingInfo.CurrentPage == 1)
            {
                litag.AddCssClass("disabled");
                anchor.MergeAttribute("href", "javascript:void(0);");
            }
            else
            {
                anchor.MergeAttribute("href", url+( pagingInfo.CurrentPage - 1).ToString());
            }
            anchor.InnerHtml = "Previous".ToString();
            litag.InnerHtml = anchor.ToString();
            result.Append(litag.ToString());
            #endregion

            #region set middle content
            for (int i = 1; i <= pagingInfo.TotalPages; i++)
            {
                litag = new TagBuilder("li");
                anchor = new TagBuilder("a");
                litag.AddCssClass("page-item");
                anchor = new TagBuilder("a");
                anchor.AddCssClass("page-link");
                anchor.InnerHtml = i.ToString();
                if (i == pagingInfo.CurrentPage)
                {
                    litag.AddCssClass("page-item active");
                    anchor.MergeAttribute("href", "javascript:void(0)");
                }
                else
                {
                    anchor.MergeAttribute("href", url + i.ToString());
                }
                litag.InnerHtml = anchor.ToString();
                result.Append(litag.ToString());
            }
            #endregion

            #region set next page

            anchor = new TagBuilder("a");
            litag = new TagBuilder("li");
            litag.AddCssClass("page-item");
            anchor.AddCssClass("page-link");
            if (pagingInfo.CurrentPage == pagingInfo.TotalPages)
            {
                litag.AddCssClass("disabled");
                anchor.MergeAttribute("href", "javascript:void(0);");
            }
            else
            {
                anchor.MergeAttribute("href", url + (pagingInfo.CurrentPage + 1).ToString());
            }
            anchor.InnerHtml = "Next".ToString();
            litag.InnerHtml = anchor.ToString();
            result.Append(litag.ToString());
            #endregion

            #region set Last page

            litag = new TagBuilder("li");
            anchor = new TagBuilder("a");

            litag.AddCssClass("page-item");
            anchor.AddCssClass("page-link");
            if (pagingInfo.CurrentPage == pagingInfo.TotalPages)
            {
                litag.AddCssClass("disabled");
                anchor.MergeAttribute("href", "javascript:void(0);");
            }
            else
            {
                anchor.MergeAttribute("href", url + (pagingInfo.TotalPages).ToString());
            }
            anchor.InnerHtml = "Last".ToString();
            litag.InnerHtml = anchor.ToString();
            result.Append(litag.ToString());
            #endregion

            ulTag.InnerHtml = result.ToString();
            return MvcHtmlString.Create(ulTag.ToString());
        }
    }
}