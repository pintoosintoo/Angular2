﻿using Sample.helper;
using Sample.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Sample.Controllers
{
    public class TeamController : Controller
    {
        // GET: Team
        public int PageSize = 5;
        public ActionResult index(int page = 1)
        {
            TeamListViewModel model = new TeamListViewModel();
            DB db = new DB();
            model = new TeamListViewModel
            {
                teamList = db.Teams.Where(x => x.ApplicationMaster.ApplicationID == 1
                && x.IsActive.HasValue && x.IsActive.Value).OrderBy(p => p.OrderNo)
                .Skip((page - 1) * PageSize)
                .Take(PageSize),
                PagingInfo = new PagingInfo
                {
                    CurrentPage = page,
                    ItemsPerPage = PageSize,
                    TotalItems = db.Teams.Where(x => x.ApplicationMaster.ApplicationID == 1 && x.IsActive.HasValue && x.IsActive.Value).Count()
                }
            };
            return View(model);
        }

        public ActionResult profile(string name)
        {
            ViewBag.name = name;
            return View();
        }
    }
}